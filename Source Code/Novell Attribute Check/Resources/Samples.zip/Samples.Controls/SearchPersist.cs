/******************************************************************************
* The MIT License
* Copyright (c) 2003 Novell Inc.  www.novell.com
* 
* Permission is hereby granted, free of charge, to any person obtaining  a copy
* of this software and associated documentation files (the Software), to deal
* in the Software without restriction, including  without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
* copies of the Software, and to  permit persons to whom the Software is 
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in 
* all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*******************************************************************************/
//
// Samples.Controls.SortSearch.cs
//
// Author:
//   Sunil Kumar (Sunilk@novell.com)
//
// (C) 2003 Novell, Inc (http://www.novell.com)
//
using System;
using Novell.Directory.Ldap;
using Novell.Directory.Ldap.Controls;

namespace Samples.Controls
{
	class SearchPersist
	{

		static  String  QuitPrompt = "\nMonitoring changes. Enter a 'q' to quit: ";

		static void Main(string[] args)
		{

			if ( args.Length != 5)
			{
				Console.WriteLine("Usage:   mint SearchPersist <host name> <ldap port>  <login dn>" + " <password> <search base>" );
				Console.WriteLine("Example: mint SearchPersist Acme.com 389"  + " \"cn=admin,o=Acme\"" + " secret \"ou=sales,o=Acme\"");
				return;
			}

			int ldapVersion  = LdapConnection.Ldap_V3;        
			String ldapHost = args[0];
			int ldapPort = System.Convert.ToInt32(args[1]);;
			String loginDN = args[2];
			String password = args[3];
			String searchBase = args[4];
			LdapSearchQueue queue = null;
			LdapSearchConstraints constraints;
			LdapPersistSearchControl psCtrl;
			LdapConnection lc = new LdapConnection();
			constraints =  new LdapSearchConstraints();

			try 
			{
				// connect to the server
				lc.Connect( ldapHost, ldapPort );
				// authenticate to the server
				lc.Bind(ldapVersion, loginDN, password);

				//Create the persistent search control
				psCtrl = new LdapPersistSearchControl(
					LdapPersistSearchControl.ANY, // any change
					true,                         //only get changes
					true,                         //return entry change controls
					true);                        //control is critcal

				// add the persistent search control to the search constraints
				constraints.setControls( psCtrl );

				// perform the search with no attributes returned
				String[] noAttrs = {LdapConnection.NO_ATTRS};
				queue = lc.Search(
					searchBase,                // container to search
					LdapConnection.SCOPE_SUB,  // search container's subtree
					"(objectClass=*)",         // search filter, all objects
					noAttrs,                   // don't return attributes
					false,                     // return attrs and values, ignored
					null,                      // use default search queue
					constraints);              // use default search constraints
			}
			catch( LdapException e ) 
			{
				Console.WriteLine( "Error: " + e.ToString() );
				try { lc.Disconnect(); } 
				catch(LdapException e2) {  }
				System.Environment.Exit(1);
			}
			// persistent search initiated without error, monitor the results
			// looping until the user quits by entering a 'q' or 'Q'

			System.IO.StreamReader in_Renamed = new System.IO.StreamReader(System.Console.OpenStandardInput());
		
			try
			{
				//loop until the user quits by entering 'q' or 'Q'
				System.Console.Out.Write(QuitPrompt);
				System.String input;
				while (true)
				{
					if (in_Renamed.Peek() != -1)
					{
						input = in_Renamed.ReadLine();
						if (input.StartsWith("q") || input.StartsWith("Q"))
							break;
						else
							System.Console.Out.Write(QuitPrompt);
					}
					if (!checkForAChange(queue))
						break;
					System.Threading.Thread.Sleep(10);
				}
			}
			catch (System.IO.IOException e)
			{
				System.Console.Out.WriteLine(e.Message);
			}
			catch (System.Threading.ThreadInterruptedException e)
			{
			}
		
			//Disconnect from the server before exiting
			try
			{
				lc.Abandon(queue); //abandon the search
				lc.Disconnect();
			}
			catch (LdapException e)
			{
				System.Console.Out.WriteLine();
				System.Console.Out.WriteLine("Error: " + e.ToString());
			}
		
			System.Environment.Exit(0);
		}
		/// <summary> Check the queue for a response. If a response has been received,
		/// print the response information.
		/// </summary>
		static private bool checkForAChange(LdapSearchQueue queue)
		{
			LdapMessage message;
			bool result = true;
		
			Console.WriteLine("inside check for a chnage..");
			try
			{
				//check if a response has been received so we don't block
				//when calling getResponse()
				if (queue.isResponseReceived())
				{
					message = queue.getResponse();
					if (message != null)
					{
						// is the response a search result reference?
						if (message is LdapSearchResultReference)
						{
							System.String[] urls = ((LdapSearchResultReference) message).Referrals;
							System.Console.Out.WriteLine("\nSearch result references:");
							for (int i = 0; i < urls.Length; i++)
								System.Console.Out.WriteLine(urls[i]);
							System.Console.Out.Write(QuitPrompt);
						}
							// is the response a search result?
						else if (message is LdapSearchResult)
						{
							LdapControl[] controls = message.Controls;
							for (int i = 0; i < controls.Length; i++)
							{
								if (controls[i] is LdapEntryChangeControl)
								{
									LdapEntryChangeControl ecCtrl = (LdapEntryChangeControl) controls[i];
								
									int changeType = ecCtrl.ChangeType;
									System.Console.Out.WriteLine("\n\nchange type: " + getChangeTypeString(changeType));
									if (changeType == LdapPersistSearchControl.MODDN)
										System.Console.Out.WriteLine("Prev. DN: " + ecCtrl.PreviousDN);
									if (ecCtrl.HasChangeNumber)
										System.Console.Out.WriteLine("Change Number: " + ecCtrl.ChangeNumber);
								
									LdapEntry entry = ((LdapSearchResult) message).Entry;
								
									System.Console.Out.WriteLine("entry: " + entry.DN);
									System.Console.Out.Write(QuitPrompt);
								}
							}
						}
							// the message is a search response
						else
						{
							LdapResponse response = (LdapResponse) message;
							int resultCode = response.ResultCode;
							if (resultCode == LdapException.SUCCESS)
							{
								System.Console.Out.WriteLine("\nUnexpected success response.");
								result = false;
							}
							else if (resultCode == LdapException.REFERRAL)
							{
								System.String[] urls = ((LdapResponse) message).Referrals;
								System.Console.Out.WriteLine("\n\nReferrals:");
								for (int i = 0; i < urls.Length; i++)
									System.Console.Out.WriteLine(urls[i]);
								System.Console.Out.Write(QuitPrompt);
							}
							else
							{
								System.Console.Out.WriteLine("Persistent search failed.");
								throw new LdapException(response.ErrorMessage, resultCode, response.MatchedDN);
							}
						}
					}
				}
			}
			catch (LdapException e)
			{
				System.Console.Out.WriteLine("Error: " + e.ToString());
				result = false;
			}
		
			return result;
		}
	
		/// <summary> Return a string indicating the type of change represented by the
		/// changeType parameter.
		/// </summary>
		private static System.String getChangeTypeString(int changeType)
		{
			System.String changeTypeString;
		
			switch (changeType)
			{
			
				case LdapPersistSearchControl.ADD: 
					changeTypeString = "ADD";
					break;
			
				case LdapPersistSearchControl.MODIFY: 
					changeTypeString = "MODIFY";
					break;
			
				case LdapPersistSearchControl.MODDN: 
					changeTypeString = "MODDN";
					break;
			
				case LdapPersistSearchControl.DELETE: 
					changeTypeString = "DELETE";
					break;
			
				default: 
					changeTypeString = "Unknown change type: " + changeType.ToString();
					break;
			
			}
		
			return changeTypeString;
		}
	} //end class SearchPersist
}